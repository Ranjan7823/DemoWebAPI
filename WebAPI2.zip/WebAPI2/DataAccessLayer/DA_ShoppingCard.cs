﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;

namespace DataAccessLayer
{
    public class DA_ShoppingCard
    {
        List<Entity.ShoppingCardEntity> ShoppingList;
        public DA_ShoppingCard()
        {
             ShoppingList = new List<Entity.ShoppingCardEntity>()

            {
                new ShoppingCardEntity {Item_Name="Laptop", Description="Dell Laptop", Item_Price=30000},
                new ShoppingCardEntity {Item_Name="Laptop12", Description="Dell Laptop", Item_Price=30000},
                new ShoppingCardEntity {Item_Name="Laptop2", Description="B Laptop", Item_Price=30000},
                new ShoppingCardEntity {Item_Name="Laptop3", Description="A Laptop", Item_Price=30000},
                new ShoppingCardEntity {Item_Name="Laptop4", Description="C Laptop", Item_Price=30000},
                new ShoppingCardEntity {Item_Name="Laptop5", Description="D Laptop", Item_Price=30000},
                new ShoppingCardEntity {Item_Name="Laptopf", Description="F Laptop", Item_Price=30000},
                new ShoppingCardEntity {Item_Name="Laptop7", Description="dd Laptop", Item_Price=30000},
                new ShoppingCardEntity {Item_Name="Laptop8", Description="ff Laptop", Item_Price=30000}
            };
        }

        public IEnumerable<ShoppingCardEntity> GetList()
        {
            return ShoppingList.ToList();
        }
        public IEnumerable<ShoppingCardEntity> GetIem(string item)
        {
            return ShoppingList.Where(i => i.Item_Name.Contains(item)).ToList();
        }
        public IEnumerable<ShoppingCardEntity> DeleteItem(string item)
        {
            var getItem = ShoppingList.SingleOrDefault(x => x.Item_Name == item);
            if (getItem != null)
                ShoppingList.Remove(getItem);
            return ShoppingList.Where(i => i.Item_Name.Contains(item)).ToList();
        }
        //public IEnumerable<ShoppingCardEntity> GetIem(string item)
        //{
        //    return ShoppingList.Where(i => i.Item_Name.Contains(item)).ToList();
        //}
    }
}
