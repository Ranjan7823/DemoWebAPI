﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using Entity;

namespace BusinessLayer
{
   public class BL_ShoppingCard
    {
        private  DA_ShoppingCard DA_ShoppingCard;
        public BL_ShoppingCard()
        {
            DA_ShoppingCard = new DA_ShoppingCard();
        }


        public IEnumerable<ShoppingCardEntity> GetList()
        {
            return DA_ShoppingCard.GetList();
        }
        public IEnumerable<ShoppingCardEntity> GetIem(string item)
        {
            return   DA_ShoppingCard.GetIem(item);
        }
        public IEnumerable<ShoppingCardEntity> DeleteItem(string item)
        {
            return DA_ShoppingCard.DeleteItem(item);
        }
    }
}
