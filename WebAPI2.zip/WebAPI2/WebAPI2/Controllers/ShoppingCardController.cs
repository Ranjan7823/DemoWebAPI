﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BusinessLayer;
using Entity;
using System.Web.Http.Cors;

namespace WebAPI2.Controllers
{
   // [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class ShoppingCardController : ApiController
    {
        private readonly BL_ShoppingCard shoppingCard;
        // GET api/<controller>
        public ShoppingCardController()
        {
            shoppingCard = new BL_ShoppingCard();
        }
        
        [Route("api/GetAllShoingCardIem")]
        [HttpGet]
        public HttpResponseMessage GetShoppingList()
        {
            IEnumerable<Entity.ShoppingCardEntity>  list= shoppingCard.GetList();
            if (list != null)
            {
                return Request.CreateResponse(HttpStatusCode.OK, list);

            }
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Items not found");
        }

        // GET api/<controller>/5
        [Route("api/SearchItem")]
        [HttpGet]
        public HttpResponseMessage GetIem(string item)
        {
            IEnumerable<Entity.ShoppingCardEntity> list = shoppingCard.GetIem(item);
        
            if (list != null)
            {
                return Request.CreateResponse(HttpStatusCode.OK, list);

            }
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Items not found");
        }

        // POST api/<controller>
        public HttpResponseMessage DeleteItem(string item)
        {
            IEnumerable<Entity.ShoppingCardEntity> list = shoppingCard.DeleteItem(item);
        
            return Request.CreateResponse(HttpStatusCode.OK, list);
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}